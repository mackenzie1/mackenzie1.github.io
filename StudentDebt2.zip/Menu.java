import java.util.Scanner;
   
public class Menu
{
   public static int showMenu()
   {
      Scanner input = new Scanner(System.in);
       
            
      int choice;
      System.out.println("Please select the calculation you would like to preform.");
      System.out.println("1. Monthly Payments over time");
      System.out.println("2. Monthly Payment");
      System.out.println("3. Show total accumulated intrest");
      System.out.println("4. Estimate future college cost");
      System.out.println("5. ");
   
      choice = input.nextInt();
   
      return choice;
   
   }
}