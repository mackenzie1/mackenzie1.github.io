//Mackenzie Harwood, Richie Williams, Sydney Balogun
//
//Calculate the intrest paid on loan and other tasks
import java.util.*;
import java.text.*;
public class StudentDebtCalculator {
      
   public static void main(String[] args) {
   
      //array list for user(we only have one user rn tho)
      List<User> users = new ArrayList<User>();
      
      NumberFormat currency = NumberFormat.getCurrencyInstance();
      
      Scanner in = new Scanner(System.in);
      System.out.println("Hi welcome to our Student debt calculator");
      System.out.print("Enter user name: ");
      String name = in.next();
      
      User newUser = new User();
      newUser.setUserName(name);
      users.add(newUser); //Add the user to the list
   
      newUser.getName();
   
      System.out.println("Enter Password:");
      String temp1 = in.next();
     
      System.out.println("ReEnter Password:");
      String temp2 = in.next();
      
      //if passwords match set the users password to that
      if (temp1.equals(temp2))
      {
         newUser.setPassword(temp1);
      }
      else
      {
         while (temp1.compareTo(temp2) != 0)
         {
            System.out.println("Passwords do match. Try again");
            
            System.out.println("Enter Password:");
            temp1 = in.next();
         
            System.out.println("Enter Password:");
            temp2 = in.next();
         }
         newUser.setPassword(temp1);
      
      }
      
      Calculation calc = new Calculation();
      
      double score;
      String str;
      //let user pick from the menu
      int menuChoice = Menu.showMenu();
      
      switch (menuChoice)
      {
         case 1 :
            score = calc.monthlyPaymentOverTime();
            break;
         case 2 :
            str = calc.monthlyPayment();
            System.out.println("Monthly payment:" + str);
            break;
         case 3 :
            score = calc.intrest();
            System.out.println("The accumulated intrest is "+ currency.format(score));
            break;
         case 4:
            score = calc.increaseCollegeCost();
            System.out.println("The estimated cost of college will be  "+ currency.format(score));
            break;

         case 5:
            newUser.loggedOut();
            System.out.println("Test.");
            break;
      
      }
      
    
   }
}