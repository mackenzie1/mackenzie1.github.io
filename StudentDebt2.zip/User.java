public class User
{
   String userName = "";
   String password= "";
   double amount = 0.0;
   double rate = 0.0;
    
 

   public void setUserName(String userName) {
      this.userName = userName;
        
   }

   public String getName() {
      System.out.println(userName);
   
      return this.userName;
   }
   
   public void setPassword(String password){
      this.password = password;
   }
   
   public void setLoanAmount(double amount) {
      this.amount = amount;
        //System.out.println(name);
   }
   
   public void setIntrestRate(double rate){
      this.rate = rate;
   }
         public boolean loggedOut() {
            boolean loggedOut = false;

            for (int i = 0; i < users.size(); i++) {
               if (users.get(i).getUsername().compareTo(username) == 0 && users.get(i).getPassword().compareTo(password) == 0) {
                  loggedOut = true;
                  break;

               } else {
                  passwordField.setText("");
                  Toolkit.getDefaultToolkit().beep();
                  JOptionPane.showMessageDialog(errorFrame,
                          "Could not authorize employee with given username and password.\n\n" +
                                  "Please reenter or contact your system administrator.\n\n",
                          "Employee Authorization Failed",
                          JOptionPane.ERROR_MESSAGE);

               }
            }

            return loggedOut;
         }
   
}