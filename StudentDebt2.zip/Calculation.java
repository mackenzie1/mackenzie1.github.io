import java.util.Scanner;
import java.text.NumberFormat;

public class Calculation
{
   //Scanner and number formatter for the methods to use
   Scanner scan = new Scanner(System.in);
   
   NumberFormat currency = NumberFormat.getCurrencyInstance();
   
   //intrest method
   
   public double intrest()
   {
      double loanAmount, intrestRate, years, moneyInIntrest;
      
      
      System.out.println("Enter you total expected loan amount: ");
      loanAmount = scan.nextDouble();
               
      NumberFormat currency = NumberFormat.getCurrencyInstance();
      
      System.out.println("Your loan amount is "+ currency.format(loanAmount) + " Enter your annual intrest rate:");
      intrestRate = scan.nextDouble();
               
      NumberFormat percent = NumberFormat.getPercentInstance();
      System.out.println("Your loan amount is "+ currency.format(loanAmount)+ " at "+ intrestRate+"%");
      System.out.println("Enter years you will pay off the loan: ");
      years = scan.nextInt();
      
      moneyInIntrest = (loanAmount * intrestRate * years)/100;
      
      return moneyInIntrest;
   }
   
   
   //monthly payment method
   
   public String monthlyPayment()
   {
      double loanAmount, rate, monthlyRate, monthlyPayments;
      int years;
      System.out.println("Enter you total expected loan amount: ");
      loanAmount = scan.nextDouble();
               
               
      System.out.println("Enter your annual intrest rate: ");
      rate = scan.nextDouble();
               
      System.out.println("Enter loan term (in years): ");
      years = scan.nextInt();
      
      double intrestRate = rate / 100;
      
      monthlyRate = intrestRate /12.0;
      
      int termsInMonths = years * 12;
      
      monthlyPayments = (loanAmount * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -termsInMonths));
      
      return currency.format(monthlyPayments);
      
      
   }
   
   
   // Monthly Payments over time
   
   public double monthlyPaymentOverTime()
   {
   
      double loanAmount, intrestRate;
      int years;
      double monthlyPayments, monthlyRate;
      
      //get Loam Amount
      System.out.println("Enter you total expected loan amount: ");
      loanAmount = scan.nextDouble();
               
      
      //get rate        
      System.out.println("Enter your annual intrest rate: ");
      double rate = scan.nextDouble();
      
      //get real intrest rate         
      intrestRate = rate / 100.0;
      
      
      //get years
      System.out.println("Enter loan term (in years): ");
      years = scan.nextInt();
      
      for(int i = 1; i <= years; i++)
      {
      
      
         monthlyRate = intrestRate /12.0;
      
         int termsInMonths = i * 12;
      
         monthlyPayments = (loanAmount * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -termsInMonths));
         
         System.out.println("The monthly payment to pay off your loan in " + i + " years is "+ currency.format(monthlyPayments));
      }
         
      return intrestRate;
   }
   public double increaseCollegeCost()
   {
      System.out.println("Enter annual cost of attendance");
      double annualCost = scan.nextDouble();
      
      System.out.println("Enter years until college");
      int yearsUntilCollege = scan.nextInt();
       
      System.out.println("Enter number of years in college");
      int yearsInCollege = scan.nextInt();
        
      System.out.println("We assue the cost of college rises 5% each year");
        
      int years = yearsUntilCollege + yearsInCollege; 
      
      
      int lastYears = years - yearsInCollege;
      
      double increase = 0.0;
                 
      for(int i = 1; i <= years; i++ ){
      
         double annualIncreaseCost = annualCost * .05;
               
         increase = annualIncreaseCost + annualCost;
               
         annualCost = increase;
         
      }
      
      return increase;
   
   }
}